Martee's Marine Bot waypoints for dod maps (V2)

Version 2...
1. dod_escape had a door waypoint on the bridge that shouldn't be there, waypoints replaced.
2. All other waypoints refreshed in this download, just in case there are other waypoints that could be too old. 


All waypoints by Martee for marine bot.

Includes all the official maps plus one custom map waypoints (dod_overlord2_b1).

Install

The "dod" folder has the correct file placement.
Just place the "dod" folder in the download into your "Half-Life" folder.


To find your dod folder…
1.	Open your Steam Library
2.	Right-click on the “Day of Defeat” icon
3.	Select “Manage” > “Browse local files” ….
4.	A folder called “Half-Life” will pop-up, the dod folder is in there.
5.	Copy and paste the “dod” folder in the download into the “Half-Life” folder.



Download dod_overlord2_b1 map here
https://dayofdefeat.home.blog/2023/02/12/dod_overlord2_b1/

or here...

https://sturmbot.org/index.php/day-of-defeat-standard-maps/download/22-day-of-defeat-standard-maps/96-dod-overlord2-b1
