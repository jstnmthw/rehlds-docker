Sturmbot waypoints for use in new_bot. 

Assembled 4th Oct 2026 (INsane sturmbot.org)

This is 743 sturmbot waypoints for various authors.

* Outside of these look for more when you download a map, 
e.g: Maps from Martee's website... https://dayofdefeat.home.blog/maps/
* Be careful when installing over these, likely the waypoints in this pack are better/newer than some older map downloads (say from 17Buddies or Gamebanana)

****How these work****
Martee's new_bot (all versions) can load these and use them.... if they are in the correct place.
Install these in dod/sturmbot/waypoints like they are in the download folder.


****INSTALL****

The "dod" folder has the correct file placement.
Just place the "dod" folder in the download into your "Half-Life" folder.


To find your dod folder…
1.	Open your Steam Library
2.	Right-click on the “Day of Defeat” icon
3.	Select “Manage” > “Browse local files” ….
4.	A folder called “Half-Life” will pop-up, the dod folder is in there.
5.	Copy and paste the “dod” folder in the download into the “Half-Life” folder.

