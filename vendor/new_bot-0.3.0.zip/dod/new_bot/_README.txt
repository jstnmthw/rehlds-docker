Extract the contents to your Half-Life folder

new_bot is a metamod plugin, so you need to add it to the plugins.ini file in your metamod install and not config.ini or it will crash
Add this line to your metamod plugins.ini:
win32 new_bot/new_bot_mm.dll

Make sure you turn off any other bots that are running by commenting out their dll in config.ini

I've provided the key bindings that I use to make waypoints. To use them enter exec newbotconfig.cfg into the console


The bot can load sturmbot waypoints and will make some conversions to get them playable as soon as possible
However, there are a few waypoints that might need some adjusting and fixing once the conversion is complete
The bot will check the sturmbot/waypoints folder if it fails to find new_bot waypoints for a map
Alternatively put the sturmbot.wpt file into the new_bot waypoints folder
Next I would recommend running waypoint check and waypoint checkpaths to find any problem waypoints
Guard and sniper waypoints will try to automatically detect if the bot should go prone at them, as sturmbot didn't have a prone waypoint tag


Guard/Sniper/Grenade waypoints
You can now have the bot aim at a specific location instead of just the general direction
So when placing them look exactly where you want the bot to look, it means that bots in sniper towers can now look down instead of just straight forwards
This is especially important for grenade waypoints as it dictates where the bot will throw the grenade
You can use the waypoint connect {flag_index} command to connect a Guard/Sniper/Grenade waypoint to a flag
If the bot's team doesn't own the flag they will not go to that waypoint. Useful for defend maps to stop bots trying to defend flags they have already lost


Obstruction waypoints
new_bot needs an obstruction waypoint on either side of an obstruction with no other waypoint types inbetween so that it can correctly detect if the blockage is present
You can chain obstruction waypoints together if needed
Once an obstruction has either been destroyed or added, the bot will detect this and update it's routing information in the background
Once the route information has finished updating, depending on the number of waypoints in the map this should take a few seconds
The bot will then be able to go through the newly opened route, or stop using that route if it is now blocked


Bomb waypoints
A bot will try use a bomb at this point, or deliver documents here
You can use waypoint connect {obstruction_wpt} to connect a bomb waypoint to an obstruction
Once the connected obstruction is clear the bot will no longer try to use this bomb waypoint


Changing waypoint stance
You can use the waypoint menu to change the stance of a waypoint(STAND/CROUCH/PRONE), so you no longer have to delete and re-add waypoints to change their stance.
The stance change tool doesn't care what stance your character is currently in and will update the waypoints position according to the desired stance.


Changing waypoint team
You can use the waypoint menu to change the team of a waypoint (ALLIES/AXIS/SPLIT/MERGE), so you no longer have to delete and re-add waypoints to change their team
ALLIES sets the waypoint to allies.
AXIS sets the waypoint to axis.
SPLIT will allow you to create a copy of the nearest waypoint in the opposite team. So if you're stood near an ALLIES waypoint it will add an AXIS waypoint at you position.
If you use this command on a NEUTRAL waypoint it will convert the NEUTRAL waypoint to ALLIES and add an AXIS waypoint at your position
Useful for creating one way paths for specific teams
MERGE allows you to combine two close together waypoints of the opposite team into one NEUTRAL waypoint. You will need to check the paths after you have done this
Useful if you accidentally split a waypoint or have loaded sturmbot waypoints and want to neaten up the waypoints


Adding waypoints
When you use the waypoint add command it will detect the stance that your character is currently in (STAND/CROUCH/PRONE) and add a waypoint of the same type.
It will also detect if you are holding down the SPRINT key and add a sprint waypoint accordingly

Special thanks
INsane for all his help with testing and encouragement!
America for helping me learn some things about HL coding!